package com.bajaj.common.validations1;

public interface ValidEmail {
}
